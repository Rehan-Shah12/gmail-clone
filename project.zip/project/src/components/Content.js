
import '../style/Content.css'
import EmailList from "./EmailList";
const Content = () => {
    return (
        <div className='Content'><EmailList/></div>
    )
}

export default Content