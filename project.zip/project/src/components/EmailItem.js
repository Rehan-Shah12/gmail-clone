function EmailItem(){
    return(
        <div className='EmailItem'>EmailItem</div>
    )
}

export default EmailItem