import EmailItem from "./EmailItem";

function EmailList(){
    return(
        <div className='EmailList'><EmailItem/></div>
    )
}

export default EmailList